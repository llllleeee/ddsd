#!/usr/bin/env bash
stdout() {
    echo -e "\033[32m$1\033[0m"
}

chmod +x *.sh
chmod +x cuocuo

if [[ -d /etc/cuocuo-client ]] || [[ -d /etc/cuocuo-server ]]; then
    stdout "--------------------------------------------------"
    stdout "         已检测到由 1.0.2 升级至 1.1.0 版本         "
    stdout "--------------------------------------------------"
    stdout "--------------------------------------------------"
    stdout "                 备份旧版隧道配置中                 "
    stdout "--------------------------------------------------"
    if [ -d /etc/cuocuo-client ]; then
        touch client.tmp

        cp -f /etc/cuocuo-client/data.json default.json
    elif [ -d /etc/cuocuo-server ]; then
        cp -f /etc/cuocuo-server/data.json default.json
    fi

    stdout "--------------------------------------------------"
    stdout "                   移除旧版隧道中                   "
    stdout "--------------------------------------------------"
    ./remove.sh

    stdout "--------------------------------------------------"
    stdout "                    安装新版本中                   "
    stdout "--------------------------------------------------"
    if [ -f client.tmp ]; then
        ./client.sh
    else
        ./server.sh
    fi

    stdout "--------------------------------------------------"
    stdout "                   更新配置文件中                   "
    stdout "--------------------------------------------------"
    cp -f default.json /etc/cuocuo/default.json
    rm -f default.json
    rm -f client.tmp

    stdout "--------------------------------------------------"
    stdout "           请认真阅读上面的输出操作隧道程序           "
    stdout "--------------------------------------------------"
    stdout "                      特别注意                      "
    stdout "--------------------------------------------------"
    stdout "1. 没有自动开启自启"
    stdout "2. 也没有帮你启动好"
    stdout "--------------------------------------------------"
else
    stdout "--------------------------------------------------"
    stdout "                   复制隧道程序中                  "
    stdout "--------------------------------------------------"
    cp -f cuocuo /usr/bin/cuocuo

    stdout "--------------------------------------------------"
    stdout "                   调整隧道权限中                  "
    stdout "--------------------------------------------------"
    chmod +x /usr/bin/cuocuo

    stdout "--------------------------------------------------"
    stdout "                   重启隧道服务中                  "
    stdout "--------------------------------------------------"
    systemctl restart cuocuo@default
fi

stdout "--------------------------------------------------"
stdout "                  升级脚本执行完毕                 "
stdout "--------------------------------------------------"
exit 0