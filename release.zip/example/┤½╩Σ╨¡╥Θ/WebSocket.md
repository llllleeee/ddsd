# WebSocket
标准的 WebSocket 协议实现

```json
[
    {
        "Type": "WebSocket",
        "Listen": ":80",
        "Secret": "cristhebest",
        "Method": "aes-256-gcm",
        "TLSCertificate": "",
        "TLSSecret": "",
        "Secure": false
    }
]
```