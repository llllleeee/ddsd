# TCP
```json
[
    {
        "Type": "TCP",
        "Listen": ":8080",
        "Secret": "cristhebest",
        "Method": "aes-256-gcm",
        "TLSCertificate": "",
        "TLSSecret": "",
        "Secure": false
    }
]
```