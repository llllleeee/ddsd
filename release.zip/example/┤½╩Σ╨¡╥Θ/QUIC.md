# QUIC
标准的 QUIC 协议实现
```
入口（Client） -> 出口（Server + Shadowsocks）

入口：1.1.1.1
出口：8.8.8.8
```

## 使用自签名证书（程序自动生成自签名证书）
### Server
```json
[
    {
        "Type": "QUIC",
        "Listen": ":443",
        "Secret": "cristhebest",
        "Method": "none",
        "TLSCertificate": "",
        "TLSSecret": "",
        "Secure": false
    }
]
```

### Client
```json
[
    {
        "Rule": [
            {
                "Listen": ":",
                "ListenPort": "444",
                "Remote": "127.0.0.1",
                "RemotePort": "444",
                "TCP": true,
                "UDP": false
            }
        ],
        "Next": [
            {
                "Type": "QUIC",
                "Remote": "8.8.8.8:443",
                "Secret": "cristhebest",
                "Method": "none",
                "Secure": false
            }
        ],
        "BalanceMode": "default"
    }
]
```

## 使用自己的证书
### Server
```json
[
    {
        "Type": "QUIC",
        "Listen": ":443",
        "Secret": "cristhebest",
        "Method": "none",
        "TLSCertificate": "/etc/cuocuo-server/ssl.crt",
        "TLSSecret": "/etc/cuocuo-server/ssl.key",
        "Secure": true
    }
]
```

### Client
```json
[
    {
        "Rule": [
            {
                "Listen": ":",
                "ListenPort": "444",
                "Remote": "127.0.0.1",
                "RemotePort": "444",
                "TCP": true,
                "UDP": false
            }
        ],
        "Next": [
            {
                "Type": "QUIC",
                "Remote": "8.8.8.8:443",
                "Secret": "cristhebest",
                "Method": "none",
                "Secure": false
            }
        ],
        "BalanceMode": "default"
    }
]
```