# 中继 负载均衡 automatic
## 功能
- 在多个中继节点中负载均衡
- 自动进行中继节点可用性检测

## Client
```json
[
    {
        "Rule": [
            {
                "Listen": ":",
                "ListenPort": "444",
                "Remote": "114.114.114.114",
                "RemotePort": "444",
                "TCP": true,
                "UDP": false
            }
        ],
        "Next": [
            {
                "Type": "WebSocket",
                "Remote": "40.0.0.1:80",
                "Secret": "cristhebest",
                "Method": "aes-256-gcm",
                "Secure": false
            },
            {
                "Type": "WebSocket",
                "Remote": "40.0.0.2:80",
                "Secret": "cristhebest",
                "Method": "aes-256-gcm",
                "Secure": false
            }
        ],
        "BalanceMode": "automatic"
    }
]
```