#!/usr/bin/env bash
stdout() {
    echo -e "\033[32m$1\033[0m"
}

stdout "--------------------------------------------------"
stdout "                  正在停止服务中                   "
stdout "--------------------------------------------------"
systemctl stop cuocuo
systemctl stop cuocuo@default

stdout "--------------------------------------------------"
stdout "                  正在禁用服务中                   "
stdout "--------------------------------------------------"
systemctl disable cuocuo
systemctl disable cuocuo@default

stdout "--------------------------------------------------"
stdout "                  正在删除服务中                   "
stdout "--------------------------------------------------"
rm -f /etc/systemd/system/cuocuo.service
rm -f /etc/systemd/system/cuocuo@.service 

stdout "--------------------------------------------------"
stdout "                  正在删除程序中                   "
stdout "--------------------------------------------------"
rm -f /usr/bin/cuocuo

stdout "--------------------------------------------------"
stdout "                  正在删除配置中                   "
stdout "--------------------------------------------------"
rm -rf /etc/cuocuo-client
rm -rf /etc/cuocuo-server
rm -rf /etc/cuocuo

stdout "--------------------------------------------------"
stdout "                  移除脚本执行完毕                 "
stdout "--------------------------------------------------"
exit 0