# 中继 负载均衡 default
## 功能
- 在多个中继节点中负载均衡
- 不带可用性检测，不会自动禁用无法使用的中继节点

## Client
```json
[
    {
        "Rule": [
            {
                "Listen": ":",
                "ListenPort": "444",
                "Remote": "114.114.114.114",
                "RemotePort": "444",
                "TCP": true,
                "UDP": false
            }
        ],
        "Next": [
            {
                "Type": "WebSocket",
                "Remote": "40.0.0.1:80",
                "Secret": "cristhebest",
                "Method": "aes-256-gcm",
                "Secure": false
            },
            {
                "Type": "WebSocket",
                "Remote": "40.0.0.2:80",
                "Secret": "cristhebest",
                "Method": "aes-256-gcm",
                "Secure": false
            },
            {
                "Type": "WebSocket",
                "Remote": "40.0.0.3:80",
                "Secret": "cristhebest",
                "Method": "aes-256-gcm",
                "Secure": false
            },
            {
                "Type": "WebSocket",
                "Remote": "40.0.0.4:80",
                "Secret": "cristhebest",
                "Method": "aes-256-gcm",
                "Secure": false
            }
        ],
        "BalanceMode": "default"
    }
]
```