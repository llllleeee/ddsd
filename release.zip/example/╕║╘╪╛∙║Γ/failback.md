# 中继 负载均衡 failback
## 功能
- 默认使用第一个中继节点，如果第一个中继节点不可用则切换至第二个中继节点

## Client
```json
[
    {
        "Rule": [
            {
                "Listen": ":",
                "ListenPort": "444",
                "Remote": "114.114.114.114",
                "RemotePort": "444",
                "TCP": true,
                "UDP": false
            }
        ],
        "Next": [
            {
                "Type": "WebSocket",
                "Remote": "40.0.0.1:80",
                "Secret": "cristhebest",
                "Method": "aes-256-gcm",
                "Secure": false
            },
            {
                "Type": "WebSocket",
                "Remote": "40.0.0.2:80",
                "Secret": "cristhebest",
                "Method": "aes-256-gcm",
                "Secure": false
            }
        ],
        "BalanceMode": "failback"
    }
]
```