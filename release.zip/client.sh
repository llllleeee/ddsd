#!/usr/bin/env bash
./deploy.sh

rm -rf /etc/cuocuo
mkdir /etc/cuocuo
cp -f example/client.json /etc/cuocuo/default.json

exit 0