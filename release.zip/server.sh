#!/usr/bin/env bash
./deploy.sh

rm -rf /etc/cuocuo
mkdir /etc/cuocuo
cp -f example/server.json /etc/cuocuo/default.json

exit 0